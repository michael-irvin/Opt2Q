"""
Opt2Q Examples
==============

Suite of Opt2Q examples and related plots.
"""
