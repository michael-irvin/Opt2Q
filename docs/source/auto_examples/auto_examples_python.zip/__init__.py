"""
Opt2Q Example Plots
-------------------
Example plots added to documentation by `sphinx-gallery`_ extension.

.. _`sphinx-gallery`: https://github.com/sphinx-gallery/sphinx-gallery

"""